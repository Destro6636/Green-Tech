const header = document.querySelector("header");
window.addEventListener("scroll", function() {
    header.classList.toggle("sticky", window.scrollY > 0);
});
var typingEffect = new Typed(".multiText",{
            strings : ["Makon","Maydon","Tabiat"],
            loop : true,
            typeSpeed : 100,
            backSpeed : 80,
            backDelay : 1500
        })
$(function(){
			$('.carousel-item').carousel-item({
				interval:1000 })
            })